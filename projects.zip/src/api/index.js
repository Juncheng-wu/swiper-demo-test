const swiper_api = 'https://v1.jinrishici.com/all.json';
export default swiper_api;