import React, { useState, useEffect } from 'react';
import './index.css';
import api from '../api/index';
let log = console.log;
const Swiper = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [swipeData, setSwipeData] = useState([]);

  const goToPrev = () => {
    if (currentIndex === 0) {
      //   setCurrentIndex(items.length - 1); // 是否要循环
    } else {
      setCurrentIndex(currentIndex - 1);
    }
  };

  const goToNext = () => {
    if (currentIndex === swipeData.length - 1) {
      //   setCurrentIndex(0);  // 是否要循环
    } else {
      setCurrentIndex(currentIndex + 1);
    }
  };

  const source = function (api) {
    const xhr = new XMLHttpRequest();
    xhr.open('GET', api, true);
    let text;
    xhr.onload = async ()=> {
      if (xhr.status >= 200 && xhr.status < 300) {
        const response = JSON.parse(xhr.responseText).content;
        log(response,'responseText');
        setSwipeData((pre)=>{
            return [...pre,response];
        })
        text = response;
      } else { console.error('失败：', xhr.status)};
    };
    // 发送请求
    xhr.send();
    return text;
  };

  //请求数据
  const getSource = async (api) => {
    const res = [
      {
        source: source(api),
        key: 1,
      },
      {
        source: source(api),
        key: 2,
      },
      {
        source: source(api),
        key: 3,
      },
    ];
    log(res, 'res');
  };

  useEffect(() => {
    getSource(api);
    log(swipeData,'swipeData');
  }, []);

  return (
    <div className="carousel">
      {console.log(swipeData, 'swipeData')}
      <button
        className="carousel-button carousel-button--left"
        onClick={goToPrev}
      >
        &lt;
      </button>
      <div className="carousel-content">
        {swipeData.map((item, index) => (
          <div
            key={index}
            className={`carousel-item ${
              index === currentIndex ? 'carousel-item--visible' : ''
            }`}
          >
            {item}
          </div>
        ))}
      </div>
      <button
        className="carousel-button carousel-button--right"
        onClick={goToNext}
      >
        &gt;
      </button>
    </div>
  );
};

export default Swiper;
