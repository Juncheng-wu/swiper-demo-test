import React, { useEffect } from 'react';
import Carousel from './swiper/index';


function App() {
  return (
    <div className="App">
      <Carousel />
    </div>
  );
}

export default App;
